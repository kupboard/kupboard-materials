var http = require('http');
var os = require('os');
http.createServer(function (req, res) {
    res.writeHead(200, {'Content-Type': 'text/html'});
    res.end(`Hello Kupboard! \nHOSTNAME=${os.hostname()} \nENV1=${process.env.ENV1} \nENV2=${process.env.ENV2}`);
}).listen(8080);
