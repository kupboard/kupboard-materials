#! /bin/sh 

curl -is -w %{http_code} -X POST gsma-server:8080/atop/execTransaction
