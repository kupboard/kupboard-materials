# Nginx

This is a sample package of kupboard collection for nginx deployment.

## Deploy

```
$ kupboard collection package -n nginx [-c <collection-name>]
```

## Delete

```
$ kupboard collection package -n nginx -a delete [-c <collection-name>]
```